import * as db from './server/db';

async function test() {
  // Verificar etapa 5250001
  const stage = await db.rawQuery('SELECT id, description, totalCost, budgetId, parentStageId FROM budget_stages WHERE id = 5250001');
  console.log('Etapa 5250001:', JSON.stringify(stage[0]));
  
  // Listar todas as etapas do budget 1080001
  const stages = await db.rawQuery('SELECT id, description, totalCost, parentStageId FROM budget_stages WHERE budgetId = 1080001');
  console.log('\nTodas as etapas do budget 1080001:');
  for (const s of stages) console.log(`  id=${s.id} parent=${s.parentStageId} total=${s.totalCost} desc=${String(s.description).substring(0,30)}`);
}

test().catch(console.error).finally(() => process.exit(0));
