import * as db from './server/db';

async function test() {
  const items = await db.getBudgetItems(1080001);
  const item = items[0];
  if (!item) { console.log('❌ Nenhum item encontrado'); return; }
  
  console.log(`Item: ${item.id} - ${String(item.description).substring(0,40)}`);
  console.log(`materialAdjustment ANTES: ${(item as any).materialAdjustment}`);
  
  const stages = await db.rawQuery('SELECT id, description, totalCost FROM budget_stages WHERE budgetId = 1080001 ORDER BY id LIMIT 5');
  console.log('\nEtapas ANTES:');
  for (const s of stages) console.log(`  ${s.id}: ${String(s.description).substring(0,30)} = R$ ${s.totalCost}`);
  
  await db.rawQuery(`UPDATE budget_items SET materialAdjustment = 50 WHERE id = ${item.id}`);
  const check = await db.rawQuery(`SELECT id, materialAdjustment FROM budget_items WHERE id = ${item.id}`);
  console.log(`\nmaterialAdjustment SALVO: ${check[0]?.materialAdjustment}`);
  
  await db.recalculateBudgetTotals(1080001);
  
  const stagesAfter = await db.rawQuery('SELECT id, description, totalCost FROM budget_stages WHERE budgetId = 1080001 ORDER BY id LIMIT 5');
  console.log('\nEtapas APÓS recalculo:');
  for (const s of stagesAfter) console.log(`  ${s.id}: ${String(s.description).substring(0,30)} = R$ ${s.totalCost}`);
  
  const budget = await db.rawQuery('SELECT totalCost FROM budgets WHERE id = 1080001');
  console.log(`\nTotal APÓS: R$ ${budget[0]?.totalCost}`);
  
  await db.rawQuery(`UPDATE budget_items SET materialAdjustment = 0 WHERE id = ${item.id}`);
  await db.recalculateBudgetTotals(1080001);
  console.log('Teste limpo.');
}

test().catch(console.error).finally(() => process.exit(0));
