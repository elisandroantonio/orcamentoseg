import DashboardLayout from "@/components/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { Building2, FileText, Package, FolderKanban } from "lucide-react";
import { Link } from "wouter";

export default function Home() {
  const { data: budgets } = trpc.budgets.list.useQuery();
  const { data: projects } = trpc.projects.list.useQuery();
  const { data: compositions } = trpc.compositions.list.useQuery();
  const { data: inputs } = trpc.inputs.list.useQuery();

  const stats = [
    {
      title: "Orçamentos",
      value: budgets?.length || 0,
      icon: FileText,
      href: "/budgets",
      description: "Total de orçamentos criados",
    },
    {
      title: "Projetos",
      value: projects?.length || 0,
      icon: FolderKanban,
      href: "/projects",
      description: "Obras em andamento",
    },
    {
      title: "Composições",
      value: compositions?.length || 0,
      icon: Building2,
      href: "/compositions",
      description: "Itens cadastrados",
    },
    {
      title: "Insumos",
      value: inputs?.length || 0,
      icon: Package,
      href: "/inputs",
      description: "Materiais e recursos",
    },
  ];

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">EG Projetos e Consultoria em Construções Ltda</h1>
          <p className="text-muted-foreground mt-2">
            Visão geral do sistema de orçamentos de obra
          </p>
        </div>

        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {stats.map((stat) => {
            const Icon = stat.icon;
            return (
              <Link key={stat.title} href={stat.href}>
                <Card className="hover:shadow-md transition-shadow cursor-pointer">
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">
                      {stat.title}
                    </CardTitle>
                    <Icon className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{stat.value}</div>
                    <p className="text-xs text-muted-foreground mt-1">
                      {stat.description}
                    </p>
                  </CardContent>
                </Card>
              </Link>
            );
          })}
        </div>

        <div className="grid gap-4 md:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle>Orçamentos Recentes</CardTitle>
              <CardDescription>Últimos orçamentos criados</CardDescription>
            </CardHeader>
            <CardContent>
              {budgets && budgets.length > 0 ? (
                <div className="space-y-3">
                  {budgets.slice(0, 5).map((budget) => (
                    <Link key={budget.id} href={`/budgets/${budget.id}`}>
                      <div className="flex items-center justify-between p-3 rounded-lg hover:bg-accent cursor-pointer">
                        <div>
                          <p className="font-medium">{budget.title}</p>
                          <p className="text-sm text-muted-foreground">
                            {budget.project?.name || "Sem projeto"}
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="font-semibold">
                            R$ {Number(budget.totalCost).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            {new Date(budget.createdAt).toLocaleDateString("pt-BR")}
                          </p>
                        </div>
                      </div>
                    </Link>
                  ))}
                </div>
              ) : (
                <p className="text-muted-foreground text-center py-8">
                  Nenhum orçamento criado ainda
                </p>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Projetos Ativos</CardTitle>
              <CardDescription>Obras em andamento</CardDescription>
            </CardHeader>
            <CardContent>
              {projects && projects.filter(p => p.status === "active").length > 0 ? (
                <div className="space-y-3">
                  {projects.filter(p => p.status === "active").slice(0, 5).map((project) => (
                    <Link key={project.id} href={`/projects/${project.id}`}>
                      <div className="flex items-center justify-between p-3 rounded-lg hover:bg-accent cursor-pointer">
                        <div>
                          <p className="font-medium">{project.name}</p>
                          <p className="text-sm text-muted-foreground">
                            {project.client || "Sem cliente"}
                          </p>
                        </div>
                        <div className="text-xs text-muted-foreground">
                          {project.location || ""}
                        </div>
                      </div>
                    </Link>
                  ))}
                </div>
              ) : (
                <p className="text-muted-foreground text-center py-8">
                  Nenhum projeto ativo
                </p>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
}
