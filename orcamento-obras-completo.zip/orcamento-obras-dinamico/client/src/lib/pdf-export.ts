import { jsPDF } from "jspdf";
import autoTable from "jspdf-autotable";

interface CompanyInfo {
  companyName: string;
  cnpj: string;
  responsibleName: string;
  responsibleTitle: string;
  phone: string;
  email: string;
}

interface ClientInfo {
  name: string;
  document: string;
  address?: string | null;
}

interface ProjectInfo {
  name: string;
  squareMeters?: string | null;
}

interface BudgetItem {
  description: string;
  unit: string;
  quantity: string;
  materialCost: number;
  laborCost: number;
  equipmentCost?: number;
  serviceCost?: number;
  otherCost?: number;
  level: number; // 0 = etapa, 1 = composição
  stageId?: number;
}

interface BudgetSummary {
  totalWithoutBDI: number;
  bdiValue: number;
  bdiPercentage: number;
  totalWithBDI: number;
  materialValue: number;
  laborValue: number;
  equipmentValue: number;
  serviceValue: number;
  otherValue: number;
}

// Função para formatar valores em reais com separador de milhares
function formatCurrency(value: number): string {
  return value.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

interface BDIParams {
  socialCharges: number;
  adminCentral: number;
  profit: number;
  taxes: number;
  risk: number;
  warranty: number;
  bdiRate: number; // taxa resultante em %
}

export async function generateBudgetPDF(
  companyInfo: CompanyInfo,
  clientInfo: ClientInfo,
  projectInfo: ProjectInfo,
  budgetTitle: string,
  items: BudgetItem[],
  summary: BudgetSummary,
  withBDI: boolean,
  includeMaterial: boolean = true,
  budgetCode?: string,
  observations?: string,
  bdiParams?: BDIParams
): Promise<void> {
  // Criar PDF em formato A4 paisagem
  const doc = new jsPDF({
    orientation: "landscape",
    unit: "mm",
    format: "a4",
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  const margin = 10;

  // Cabeçalho com 3 colunas: Cliente/Obra | Empresa | Logo
  // Em A4 paisagem: pageWidth = 297mm, centerX = 148.5mm
  // Coluna empresa começa em centerX - 20 = ~128.5mm
  // Texto da coluna 1 começa em margin + labelWidth = 10 + 35 = 45mm
  // Largura disponível para texto = 128.5 - 45 - 5 (margem segurança) = ~78.5mm
  const centerX = pageWidth / 2;
  const labelWidth = 35; // Largura reservada para o label (ex: "PROPRIETÁRIO:")
  const col2StartX = centerX - 20; // Onde começa a coluna 2 (empresa)
  const textStartX = margin + labelWidth; // Onde começa o texto do valor
  const textMaxWidth = col2StartX - textStartX - 5; // Largura máxima com margem de segurança de 5mm

  // Coluna 1: Dados do Cliente/Obra (esquerda)
  doc.setFontSize(8);
  doc.setFont("helvetica", "bold");
  let yPos = margin + 5;
  
  // Helper para renderizar linha com quebra de texto
  const renderHeaderRow = (label: string, value: string, isLink = false): number => {
    doc.setFont("helvetica", "bold");
    doc.text(label, margin, yPos);
    doc.setFont("helvetica", "normal");
    if (isLink) doc.setTextColor(0, 0, 255);
    const lines = doc.splitTextToSize(value, textMaxWidth);
    doc.text(lines, margin + labelWidth, yPos);
    if (isLink) doc.setTextColor(0, 0, 0);
    const lineHeight = 5;
    const rowHeight = Math.max(lineHeight, lines.length * lineHeight);
    yPos += rowHeight;
    return rowHeight;
  };

  renderHeaderRow("PROPRIETÁRIO:", clientInfo.name);
  renderHeaderRow("LOCAL:", clientInfo.address || "N/A");
  renderHeaderRow("OBRA:", projectInfo.name);
  renderHeaderRow("RESPONSÁVEL:", companyInfo.responsibleName);
  renderHeaderRow("DATA:", new Date().toLocaleDateString("pt-BR"));
  renderHeaderRow("ORÇAMENTO:", budgetTitle);
  
  if (budgetCode) {
    renderHeaderRow("CÓDIGO:", budgetCode);
  }

  // Calcular altura do cabeçalho dinamicamente com base no conteúdo
  const headerHeight = Math.max(45, yPos - margin + 5);

  // Coluna 2: Dados da Empresa (centro)
  // centerX já declarado acima
  yPos = margin + 5;
  
  doc.setFont("helvetica", "bold");
  doc.text("EMPRESA:", centerX - 20, yPos, { align: "right" });
  doc.setFont("helvetica", "normal");
  doc.text(companyInfo.companyName, centerX - 18, yPos);
  
  yPos += 5;
  doc.setFont("helvetica", "bold");
  doc.text("CNPJ:", centerX - 20, yPos, { align: "right" });
  doc.setFont("helvetica", "normal");
  doc.text(companyInfo.cnpj, centerX - 18, yPos);
  
  yPos += 5;
  doc.setFont("helvetica", "bold");
  doc.text("CIDADE:", centerX - 20, yPos, { align: "right" });
  doc.setFont("helvetica", "normal");
  doc.text("XANXERÊ/SC", centerX - 18, yPos);
  
  yPos += 5;
  doc.setFont("helvetica", "bold");
  doc.text("RESPONSÁVEL:", centerX - 20, yPos, { align: "right" });
  doc.setFont("helvetica", "normal");
  doc.text(`${companyInfo.responsibleTitle} ${companyInfo.responsibleName}`, centerX - 18, yPos);
  
  yPos += 5;
  doc.setFont("helvetica", "bold");
  doc.text("TELEFONE:", centerX - 20, yPos, { align: "right" });
  doc.setFont("helvetica", "normal");
  doc.text(companyInfo.phone, centerX - 18, yPos);
  
  yPos += 5;
  doc.setFont("helvetica", "bold");
  doc.text("EMAIL:", centerX - 20, yPos, { align: "right" });
  doc.setFont("helvetica", "normal");
  doc.setTextColor(0, 0, 255);
  doc.text(companyInfo.email, centerX - 18, yPos);
  doc.setTextColor(0, 0, 0);

  // Coluna 3: Logo (direita) - tentar carregar, mas não falhar se não conseguir
  try {
    const logoData = await fetch("/manus-storage/company-logo_43a9a83e.png").then(r => r.blob()).then(b => new Promise<string>((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(reader.result as string);
      reader.onerror = reject;
      reader.readAsDataURL(b);
    }));
    
    const logoWidth = 50;
    const logoHeight = 40;
    const logoX = pageWidth - margin - logoWidth;
    const logoY = margin;
    
    doc.addImage(logoData, "PNG", logoX, logoY, logoWidth, logoHeight);
  } catch (error) {
    console.warn("Logo não carregada, continuando sem logo");
  }

  // Linha separadora
  doc.setLineWidth(0.5);
  doc.line(margin, margin + headerHeight, pageWidth - margin, margin + headerHeight);

  // Tabela de composições
  const tableStartY = margin + headerHeight + 5;
  
  // Calcular totais
  let totalMaterial = 0;
  let totalLabor = 0;
  let grandTotal = 0;
  let itemNumber = 0;

  const tableData = items.map((item: any) => {
    if (item.isStageHeader) {
      // Etapa ou sub-etapa (linha de cabeçalho com total)
      const bgColor = item.level === 0 ? [30, 64, 175] : [70, 100, 200]; // Azul mais escuro para etapas principais
      return [
        "",
        { content: item.description, colSpan: 7, styles: { fontStyle: "bold" as const, fillColor: bgColor as [number, number, number], textColor: 255, halign: "left" as const } },
        { content: `R$ ${formatCurrency(item.stageTotal)}`, styles: { fontStyle: "bold" as const, fillColor: bgColor as [number, number, number], textColor: 255, halign: "right" as const } },
      ];
    } else if (item.isInput) {
      // Insumo (indentado)
      const indent = "  ".repeat(item.level);
      const coeff = parseFloat(item.coefficient) || 0;
      const unitCost = parseFloat(item.unitCost) || 0;
      const inputTotal = coeff * unitCost;
      const isLabor = item.inputType === 'labor' || item.inputType === 'service';
      const matUnit = (!isLabor && includeMaterial) ? unitCost : 0;
      const labUnit = isLabor ? unitCost : 0;
      const matTotal = matUnit * coeff;
      const labTotal = labUnit * coeff;
      return [
        item.itemNumber || "",
        indent + item.description,
        coeff ? coeff.toFixed(4) : "",
        item.unit || "",
        matUnit ? `R$ ${formatCurrency(matUnit)}` : "",
        labUnit ? `R$ ${formatCurrency(labUnit)}` : "",
        matTotal ? `R$ ${formatCurrency(matTotal)}` : "",
        labTotal ? `R$ ${formatCurrency(labTotal)}` : "",
        inputTotal ? `R$ ${formatCurrency(inputTotal)}` : "",
      ];
    } else {
      // Item (composição ou serviço)
      const qty = parseFloat(item.quantity);
      const materialUnit = includeMaterial ? item.materialCost : 0;
      const laborUnit = item.laborCost;
      const materialTotal = materialUnit * qty;
      const laborTotal = laborUnit * qty;
      const priceTotal = materialTotal + laborTotal;
      
      // Não acumular filhos de compostos no total geral (o pai já tem o total agregado)
      if (!item.isCompositeChild) {
        totalMaterial += materialTotal;
        totalLabor += laborTotal;
        grandTotal += priceTotal;
      }
      
      const indent = item.level > 0 ? "  " : "";
      return [
        item.itemNumber || "",
        indent + item.description,
        qty.toFixed(2),
        item.unit,
        `R$ ${formatCurrency(materialUnit)}`,
        `R$ ${formatCurrency(laborUnit)}`,
        `R$ ${formatCurrency(materialTotal)}`,
        `R$ ${formatCurrency(laborTotal)}`,
        `R$ ${formatCurrency(priceTotal)}`,
      ];
    }
  });

  // Adicionar linha de totais
  tableData.push([
    "",
    "TOTAL",
    "",
    "",
    "",
    "",
    `R$ ${formatCurrency(totalMaterial)}`,
    `R$ ${formatCurrency(totalLabor)}`,
    `R$ ${formatCurrency(grandTotal)}`,
  ]);

  autoTable(doc, {
    startY: tableStartY,
    head: [[
      "ITEM",
      "DESCRIÇÃO",
      "QTDE",
      "UN",
      "VALOR UNIT. MAT",
      "VALOR UNIT. M.O.",
      "VALOR TOTAL MATERIAL",
      "VALOR TOTAL M.O.",
      "PREÇO TOTAL"
    ]],
    body: tableData,
    styles: {
      fontSize: 7,
      cellPadding: 2,
    },
    headStyles: {
      fillColor: [41, 128, 185] as [number, number, number],
      textColor: 255,
      fontStyle: "bold" as const,
      halign: "center" as const,
    },
    columnStyles: {
      0: { cellWidth: 12, halign: "center" as const }, // ITEM
      1: { cellWidth: 95 }, // Descrição (aumentado para acomodar textos longos)
      2: { cellWidth: 14, halign: "right" as const }, // QTDE
      3: { cellWidth: 11, halign: "center" as const }, // UN
      4: { cellWidth: 24, halign: "right" as const }, // VALOR UNIT. MAT
      5: { cellWidth: 24, halign: "right" as const }, // VALOR UNIT. M.O.
      6: { cellWidth: 28, halign: "right" as const }, // VALOR TOTAL MATERIAL
      7: { cellWidth: 28, halign: "right" as const }, // VALOR TOTAL M.O.
      8: { cellWidth: 28, halign: "right" as const }, // PREÇO TOTAL
    },
    didParseCell: function (data) {
      const item = items[data.row.index] as any;
      // Estilizar linha de totais (última linha)
      if (data.row.index === tableData.length - 1) {
        data.cell.styles.fillColor = [30, 64, 175] as [number, number, number]; // Azul #1e40af
        data.cell.styles.textColor = 255; // Branco
        data.cell.styles.fontStyle = "bold";
      } else if (item && item.isCompositeHeader) {
        // Serviço Composto pai: fundo azul bem claro (#DBEAFE)
        data.cell.styles.fillColor = [219, 234, 254] as [number, number, number];
        data.cell.styles.textColor = [30, 64, 175] as unknown as number; // Azul escuro
        data.cell.styles.fontStyle = "bold";
      }
    },
    margin: { left: margin, right: margin },
  });

    // Resumo financeiro removido - totais já estão na última linha da tabela;

  // Adicionar observações no rodapé se existirem
  if (observations && observations.trim()) {
    const finalY = (doc as any).lastAutoTable.finalY || tableStartY + 50;
    const observationsY = finalY + 10;
    
    doc.setFontSize(8);
    doc.setFont("helvetica", "bold");
    doc.text("OBSERVAÇÕES:", margin, observationsY);
    
    doc.setFont("helvetica", "normal");
    const splitObservations = doc.splitTextToSize(observations, pageWidth - 2 * margin);
    doc.text(splitObservations, margin, observationsY + 5);
  }

  // Salvar PDF
  const filename = `orcamento-${budgetTitle.replace(/\s+/g, "-").toLowerCase()}-${withBDI ? "com-bdi" : "preco-real"}.pdf`;
  doc.save(filename);
}
