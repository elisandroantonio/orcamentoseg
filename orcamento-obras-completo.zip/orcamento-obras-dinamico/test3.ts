import * as db from './server/db';

async function test() {
  // Verificar etapa 5190004
  const stage = await db.rawQuery('SELECT id, description, totalCost, parentStageId FROM budget_stages WHERE id = 5190004');
  console.log('Etapa 5190004:', JSON.stringify(stage[0]));
  
  // Verificar item 11100018
  const item = await db.rawQuery('SELECT id, stageId, materialCost, totalCost, materialAdjustment FROM budget_items WHERE id = 11100018');
  console.log('Item 11100018:', JSON.stringify(item[0]));
  
  // Salvar materialAdjustment=50 no item 11100018
  await db.rawQuery('UPDATE budget_items SET materialAdjustment = 50 WHERE id = 11100018');
  
  // Recalcular
  await db.recalculateBudgetTotals(1080001);
  
  // Verificar etapa após
  const stageAfter = await db.rawQuery('SELECT id, totalCost FROM budget_stages WHERE id = 5190004');
  console.log('\nEtapa 5190004 APÓS:', JSON.stringify(stageAfter[0]));
  
  const before = Number(stage[0]?.totalCost);
  const after = Number(stageAfter[0]?.totalCost);
  console.log(`Diferença: R$ ${(after - before).toFixed(2)}`);
  console.log(Math.abs(after - before) > 1 ? '✅ FUNCIONOU!' : '❌ NÃO FUNCIONOU');
  
  // Limpar
  await db.rawQuery('UPDATE budget_items SET materialAdjustment = 0 WHERE id = 11100018');
  await db.recalculateBudgetTotals(1080001);
}

test().catch(console.error).finally(() => process.exit(0));
