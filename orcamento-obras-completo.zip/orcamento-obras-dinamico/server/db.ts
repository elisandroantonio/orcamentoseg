import { eq, and, desc, sql, or, like } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { 
  InsertUser, users,
  inputs, compositions, compositionInputs,
  projects, budgets, budgetItems, budgetItemInputs, budgetStages, budgetItemBdiConfig,
  scheduleActivities, schedulePeriods, disbursements, financialTransactions, FinancialTransaction
} from "../drizzle/schema";
import { ENV } from './_core/env';

// URL do banco de dados original com todos os dados do usuário
const ORIGINAL_DB_URL = "mysql://2ASSYqZeNL7nzRP.d5b8f8c4b82a:sS8lpl4KmQtej7lp69i0@gateway02.us-east-1.prod.aws.tidbcloud.com:4000/7rmYa7xiwR53zaRFAaits3?ssl={\"rejectUnauthorized\":true}";

let _db: ReturnType<typeof drizzle> | null = null;
export async function getDb() {
  const dbUrl = ORIGINAL_DB_URL || process.env.DATABASE_URL;
  if (!_db && dbUrl) {
    try {
      _db = drizzle(dbUrl);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// Direct mysql2 query helper — bypasses Drizzle prepared statements (needed for TiDB compatibility with complex JOINs)
import mysql2 from 'mysql2/promise';
let _rawConn: mysql2.Connection | null = null;
async function getRawConn() {
  const dbUrl = ORIGINAL_DB_URL || process.env.DATABASE_URL;
  if (!dbUrl) throw new Error('No DATABASE_URL');
  if (!_rawConn) {
    _rawConn = await mysql2.createConnection(dbUrl);
  }
  return _rawConn;
}
export async function rawQuery(sql: string): Promise<any[]> {
  try {
    const conn = await getRawConn();
    const [rows] = await conn.query(sql);
    return rows as any[];
  } catch (err: any) {
    // reconnect once on connection error
    _rawConn = null;
    const conn = await getRawConn();
    const [rows] = await conn.query(sql);
    return rows as any[];
  }
}

export async function rawQueryParams(sql: string, params: any[]): Promise<any[]> {
  try {
    const conn = await getRawConn();
    const [rows] = await conn.execute(sql, params);
    return rows as any[];
  } catch (err: any) {
    _rawConn = null;
    const conn = await getRawConn();
    const [rows] = await conn.execute(sql, params);
    return rows as any[];
  }
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// Inputs
export async function getInputsByUserId(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(inputs).where(eq(inputs.userId, userId)).orderBy(desc(inputs.createdAt));
}

export async function getInputById(id: number, userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(inputs).where(and(eq(inputs.id, id), eq(inputs.userId, userId))).limit(1);
  return result[0];
}

export async function searchInputs(userId: number, search?: string) {
  const db = await getDb();
  if (!db) return [];
  
  // Construir condições de busca
  const conditions: any[] = [eq(inputs.userId, userId)];
  
  // Se houver busca, adicionar filtro por palavras-chave
  if (search && search.trim()) {
    const keywords = search.trim().split(/\s+/); // Dividir por espaços
    const searchConditions = keywords.map(keyword => 
      or(
        like(inputs.description, `%${keyword}%`),
        like(inputs.code, `%${keyword}%`)
      )
    );
    conditions.push(...searchConditions);
  }
  
  return db.select()
    .from(inputs)
    .where(and(...conditions))
    .orderBy(desc(inputs.createdAt));
}

// Compositions
export async function getCompositionsByUserId(userId: number, search?: string) {
  const db = await getDb();
  if (!db) return [];
  
  // Construir condições de busca
  const conditions: any[] = [eq(compositions.userId, userId)];
  
  // Se houver busca, adicionar filtro por palavras-chave
  if (search && search.trim()) {
    const keywords = search.trim().split(/\s+/); // Dividir por espaços
    const searchConditions = keywords.map(keyword => 
      or(
        like(compositions.description, `%${keyword}%`),
        like(compositions.code, `%${keyword}%`)
      )
    );
    conditions.push(...searchConditions);
  }
  
  return db.select()
    .from(compositions)
    .where(and(...conditions))
    .orderBy(desc(compositions.createdAt));
}

export async function getCompositionById(id: number, userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(compositions).where(and(eq(compositions.id, id), eq(compositions.userId, userId))).limit(1);
  return result[0];
}

export async function getCompositionInputs(compositionId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select({
    id: compositionInputs.id,
    compositionId: compositionInputs.compositionId,
    inputId: compositionInputs.inputId,
    quantity: compositionInputs.quantity,
    coefficient: compositionInputs.coefficient,
    input: inputs,
  }).from(compositionInputs)
    .leftJoin(inputs, eq(compositionInputs.inputId, inputs.id))
    .where(eq(compositionInputs.compositionId, compositionId));
}

// Projects
export async function getProjectsByUserId(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(projects).where(eq(projects.userId, userId)).orderBy(desc(projects.createdAt));
}

export async function getProjectById(id: number, userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(projects).where(and(eq(projects.id, id), eq(projects.userId, userId))).limit(1);
  return result[0];
}

// Budgets
export async function getBudgetsByUserId(userId: number) {
  const db = await getDb();
  if (!db) return [];
  const { clients } = await import("../drizzle/schema");
  return db.select({
    id: budgets.id,
    userId: budgets.userId,
    clientId: budgets.clientId,
    projectId: budgets.projectId,
    title: budgets.title,
    description: budgets.description,
    totalCost: budgets.totalCost,
    totalLaborHours: budgets.totalLaborHours,
    startDate: budgets.startDate,
    endDate: budgets.endDate,
    durationMonths: budgets.durationMonths,
    periodType: budgets.periodType,
    status: budgets.status,
    workStatus: budgets.workStatus,
    frozenAt: budgets.frozenAt,
    frozenBy: budgets.frozenBy,
    createdAt: budgets.createdAt,
    updatedAt: budgets.updatedAt,
    project: projects,
    client: clients,
  }).from(budgets)
    .leftJoin(projects, eq(budgets.projectId, projects.id))
    .leftJoin(clients, eq(budgets.clientId, clients.id))
    .where(eq(budgets.userId, userId))
    .orderBy(desc(budgets.createdAt));
}

export async function getBudgetById(id: number, userId: number) {
  // Usar rawQuery para evitar problema de JOIN varchar/int no TiDB
  // (budgets.projectId é varchar no banco mas projects.id é int)
  const rows = await rawQuery(
    `SELECT b.id, b.userId, b.clientId, b.projectId, b.title, b.squareMeters,
            b.description, b.observations, b.socialCharges, b.adminCentral,
            b.profit, b.taxes, b.risk, b.warranty,
            b.totalMaterialCost, b.totalLaborCost, b.totalCost, b.totalLaborHours,
            b.startDate, b.endDate, b.durationMonths, b.periodType,
            b.status, b.workStatus, b.frozenAt, b.frozenBy,
            b.includeMaterial, b.createdAt, b.updatedAt, b.code,
            p.id as proj_id, p.userId as proj_userId, p.name as proj_name,
            p.client as proj_client, p.location as proj_location,
            p.description as proj_description, p.startDate as proj_startDate,
            p.endDate as proj_endDate, p.status as proj_status,
            p.createdAt as proj_createdAt, p.updatedAt as proj_updatedAt
     FROM budgets b
     LEFT JOIN projects p ON CAST(b.projectId AS UNSIGNED) = p.id
     WHERE b.id = ${id} AND b.userId = ${userId}
     LIMIT 1`
  );
  if (!rows || rows.length === 0) return undefined;
  const row = rows[0] as any;
  const project = row.proj_id ? {
    id: row.proj_id,
    userId: row.proj_userId,
    name: row.proj_name,
    client: row.proj_client,
    location: row.proj_location,
    description: row.proj_description,
    startDate: row.proj_startDate,
    endDate: row.proj_endDate,
    status: row.proj_status,
    createdAt: row.proj_createdAt,
    updatedAt: row.proj_updatedAt,
  } : null;
  return {
    id: row.id,
    userId: row.userId,
    clientId: row.clientId,
    projectId: row.projectId,
    title: row.title,
    squareMeters: row.squareMeters,
    description: row.description,
    observations: row.observations,
    socialCharges: row.socialCharges,
    adminCentral: row.adminCentral,
    profit: row.profit,
    taxes: row.taxes,
    risk: row.risk,
    warranty: row.warranty,
    totalMaterialCost: row.totalMaterialCost,
    totalLaborCost: row.totalLaborCost,
    totalCost: row.totalCost,
    totalLaborHours: row.totalLaborHours,
    startDate: row.startDate,
    endDate: row.endDate,
    durationMonths: row.durationMonths,
    periodType: row.periodType,
    status: row.status,
    workStatus: row.workStatus,
    frozenAt: row.frozenAt,
    frozenBy: row.frozenBy,
    includeMaterial: row.includeMaterial,
    createdAt: row.createdAt,
    updatedAt: row.updatedAt,
    code: row.code,
    project,
  };
}

export async function getBudgetItems(budgetId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(budgetItems).where(eq(budgetItems.budgetId, budgetId)).orderBy(budgetItems.order);
}

// Recalcular custos da composição baseado nos insumos
export async function recalculateCompositionCosts(compositionId: number) {
  const db = await getDb();
  if (!db) return;
  
  const inputs = await getCompositionInputs(compositionId);
  
  let materialCost = 0;
  let laborCost = 0;
  let equipmentCost = 0;
  
  for (const item of inputs) {
    if (!item.input) continue;
    const cost = Number(item.input.unitCost) * Number(item.coefficient);
    if (item.input.type === "material") {
      materialCost += cost;
    } else if (item.input.type === "labor") {
      laborCost += cost;
    } else if (item.input.type === "equipment") {
      equipmentCost += cost;
    }
  }
  
  await db.update(compositions)
    .set({ 
      materialCost: materialCost.toFixed(2), 
      laborCost: laborCost.toFixed(2),
      equipmentCost: equipmentCost.toFixed(2)
    })
    .where(eq(compositions.id, compositionId));
}

// Recalcular totalCost de um item de composição baseado nos insumos customizados ou na composição
export async function recalculateItemTotalCost(budgetItemId: number) {
  const db = await getDb();
  if (!db) return;
  
  const item = await db.select().from(budgetItems).where(eq(budgetItems.id, budgetItemId)).limit(1);
  if (!item[0]) return;
  
  const budgetItem = item[0];
  
  // Se é uma composição, recalcular baseado nos insumos
  if (budgetItem.type === 'composition' && budgetItem.compositionId) {
    // Verificar se há customizações (budgetItemInputs)
    const customInputs = await db.select().from(budgetItemInputs).where(eq(budgetItemInputs.budgetItemId, budgetItemId));
    
    let materialCost = 0;
    let laborCost = 0;
    let equipmentCost = 0;
    
    if (customInputs.length > 0) {
      // Usar customizações
      for (const customInput of customInputs) {
        const input = await db.select().from(inputs).where(eq(inputs.id, customInput.inputId)).limit(1);
        if (input[0]) {
          const cost = Number(customInput.coefficient) * Number(customInput.unitCost);
          const inputType = input[0].type.toLowerCase();
          if (inputType === 'material') {
            materialCost += cost;
          } else if (inputType === 'labor') {
            laborCost += cost;
          } else if (inputType === 'equipment') {
            equipmentCost += cost;
          }
        }
      }
    } else {
      // Usar composição padrão
      const composition = await db.select().from(compositions).where(eq(compositions.id, budgetItem.compositionId)).limit(1);
      if (composition[0]) {
        materialCost = Number(composition[0].materialCost || 0);
        laborCost = Number(composition[0].laborCost || 0);
        equipmentCost = Number(composition[0].equipmentCost || 0);
      }
    }
    
    const unitCost = materialCost + laborCost + equipmentCost;
    const totalCost = Number(budgetItem.quantity) * unitCost;
    
    await db.update(budgetItems)
      .set({ 
        materialCost: materialCost.toFixed(2),
        laborCost: laborCost.toFixed(2),
        equipmentCost: equipmentCost.toFixed(2),
        unitCost: unitCost.toFixed(2),
        totalCost: totalCost.toFixed(2)
      })
      .where(eq(budgetItems.id, budgetItemId));
  }
}

export async function recalculateBudgetTotals(budgetId: number) {
  const db = await getDb();
  if (!db) return;
  
  // Usar rawQuery para evitar cache de prepared statements do Drizzle
  const items = await rawQuery(`SELECT * FROM budget_items WHERE budgetId = ${budgetId} ORDER BY \`order\``);
  
  // Recalcular totalCost de cada item
  for (const item of items) {
    if (item.type === 'composition') {
      await recalculateItemTotalCost(item.id);
    }
  }
  
  // Obter items novamente após recalcular (com rawQuery para pegar materialAdjustment atualizado)
  const updatedItems = await rawQuery(`SELECT * FROM budget_items WHERE budgetId = ${budgetId} ORDER BY \`order\``);
  
  // Recalcular totais das sub-etapas
  const stages = await db.select().from(budgetStages).where(eq(budgetStages.budgetId, budgetId));
  
  // LOG: verificar se updatedItems tem materialAdjustment
  const itemsWithAdj = updatedItems.filter((i: any) => Number(i.materialAdjustment) !== 0);
  if (itemsWithAdj.length > 0) {
    console.log('[recalc] Items com materialAdjustment:', itemsWithAdj.map((i: any) => `id=${i.id}(${typeof i.id}) matAdj=${i.materialAdjustment} stageId=${i.stageId}(${typeof i.stageId})`));
    // Verificar se o stageId do item existe nas stages
    for (const adj of itemsWithAdj) {
      const found = stages.find((s: any) => s.id === (adj as any).stageId);
      const foundNum = stages.find((s: any) => Number(s.id) === Number((adj as any).stageId));
      console.log(`[recalc] stage.id type: ${stages[0] ? typeof stages[0].id : 'N/A'} | found(===): ${!!found} | found(Number): ${!!foundNum}`);
    }
  }
  console.log('[recalc] Total updatedItems:', updatedItems.length, '| Total stages:', stages.length);

  // PASSO 1: Recalcular APENAS sub-etapas (que têm parentStageId)
  for (const stage of stages) {
    if (stage.parentStageId !== null) {
      // É uma sub-etapa, somar apenas seus itens diretos
      const stageItems = updatedItems.filter((item: any) => item.stageId === stage.id);
      const stageTotalCost = stageItems.reduce((sum: number, item: any) => {
        const matAdj = 1 + Number(item.materialAdjustment || 0) / 100;
        const labAdj = 1 + Number(item.laborAdjustment || 0) / 100;
        const qty = Number(item.quantity || 1);
        const mat = Number(item.materialCost || 0) * matAdj;
        const lab = Number(item.laborCost || 0) * labAdj;
        const eq = Number(item.equipmentCost || 0);
        const svc = Number(item.serviceCost || 0);
        const oth = Number(item.otherCost || 0);
        return sum + (mat + lab + eq + svc + oth) * qty;
      }, 0);
      
      await rawQuery(`UPDATE budget_stages SET totalCost = '${stageTotalCost.toFixed(2)}' WHERE id = ${stage.id}`);
    }
  }
  
  // PASSO 2: Recalcular APENAS etapas pai (que NÃO têm parentStageId)
  for (const stage of stages) {
    if (stage.parentStageId === null) {
      // É uma etapa pai, somar itens diretos + totais de sub-etapas
      const directItems = updatedItems.filter(item => item.stageId === stage.id);
      const childStages = stages.filter(s => s.parentStageId === stage.id);
      
      const directItemsTotal = directItems.reduce((sum, item) => {
        const matAdj = 1 + Number((item as any).materialAdjustment || 0) / 100;
        const labAdj = 1 + Number((item as any).laborAdjustment || 0) / 100;
        const qty = Number((item as any).quantity || 1);
        const mat = Number((item as any).materialCost || 0) * matAdj;
        const lab = Number((item as any).laborCost || 0) * labAdj;
        const eq = Number((item as any).equipmentCost || 0);
        const svc = Number((item as any).serviceCost || 0);
        const oth = Number((item as any).otherCost || 0);
        if (Number((item as any).materialAdjustment) !== 0) {
          console.log(`[recalc-calc] item=${(item as any).id} mat=${(item as any).materialCost} matAdj=${(item as any).materialAdjustment} matAdjMult=${matAdj} qty=${qty} result=${(mat+lab+eq+svc+oth)*qty}`);
        }
        return sum + (mat + lab + eq + svc + oth) * qty;
      }, 0);
      const childStagesTotal = childStages.reduce((sum, child) => sum + Number(child.totalCost), 0);
      
      const parentTotalCost = directItemsTotal + childStagesTotal;
      if (stage.id === 5250001) {
        console.log(`[recalc-stage5250001] directItemsTotal=${directItemsTotal} childStagesTotal=${childStagesTotal} parentTotalCost=${parentTotalCost} (before=${stage.totalCost})`);
      }
      
      await rawQuery(`UPDATE budget_stages SET totalCost = '${parentTotalCost.toFixed(2)}' WHERE id = ${stage.id}`);
      if (stage.id === 5250001) {
        console.log(`[recalc-saved] Etapa 5250001 salva com totalCost=${parentTotalCost.toFixed(2)}`);
      }
    }
  }
  
  // Buscar parâmetros de BDI do orçamento
  const budget = await db.select().from(budgets).where(eq(budgets.id, budgetId)).limit(1);
  if (!budget[0]) return;
  
  const socialCharges = Number(budget[0].socialCharges);
  const profit = Number(budget[0].profit);
  const taxes = Number(budget[0].taxes);
  const risk = Number(budget[0].risk);
  const warranty = Number(budget[0].warranty);
  
  // Buscar configurações de BDI de todos os itens (rawQuery para evitar cache de prepared statements)
  const bdiConfigs: Record<number, { applyBdiToMaterial: boolean; applyBdiToLabor: boolean; additionalIncrement: number }> = {};
  const allBdiConfigs = await rawQuery(
    `SELECT budgetItemId, applyBdiToMaterial, applyBdiToLabor, additionalIncrement
     FROM budget_item_bdi_config
     WHERE budgetItemId IN (${updatedItems.map(i => i.id).join(',') || '0'})`
  );
  for (const config of allBdiConfigs) {
    bdiConfigs[config.budgetItemId] = {
      applyBdiToMaterial: Boolean(config.applyBdiToMaterial),
      applyBdiToLabor: Boolean(config.applyBdiToLabor),
      additionalIncrement: Number(config.additionalIncrement || 0)
    };
  }
  
  // Calcular totalCost COM BDI aplicado
  let totalMaterialWithBDI = 0;
  let totalLaborWithBDI = 0;
  let totalLaborHours = 0;
  
  for (const item of updatedItems) {
    const qty = Number(item.quantity);
    const material = Number(item.materialCost || 0);
    const labor = Number(item.laborCost || 0);
    const equipment = Number(item.equipmentCost || 0);
    const service = Number(item.serviceCost || 0);
    const other = Number(item.otherCost || 0);
    
    // Buscar configuração de BDI para este item
    const itemConfig = bdiConfigs[item.id] || { applyBdiToMaterial: true, applyBdiToLabor: true, additionalIncrement: 0 };
    
    // BDI completo
    const bdiMultiplier = 1 + (profit + taxes + risk + warranty) / 100;
    
    // Aplicar ajuste de material e M.O. (equalização)
    const matAdjMultiplier = 1 + Number(item.materialAdjustment || 0) / 100;
    const labAdjMultiplier = 1 + Number(item.laborAdjustment || 0) / 100;
    const materialAdjusted = material * matAdjMultiplier;
    const laborAdjusted = labor * labAdjMultiplier;
    const laborWithChargesAdj = laborAdjusted * (1 + socialCharges / 100);
    
    // Aplicar BDI ao material apenas se configurado
    const materialWithBDI = itemConfig.applyBdiToMaterial ? materialAdjusted * bdiMultiplier : materialAdjusted;
    
    // Aplicar BDI à mão de obra apenas se configurado
    const laborWithBDI = itemConfig.applyBdiToLabor ? laborWithChargesAdj * bdiMultiplier : laborWithChargesAdj;
    
    // Equipment, service e other: aplicar BDI SEM encargos sociais
    const equipmentWithBDI = equipment * bdiMultiplier;
    const serviceWithBDI = service * bdiMultiplier;
    const otherWithBDI = other * bdiMultiplier;
    
    // Total de M.O. = labor com BDI + equipment/service/other com BDI
    let totalLaborItem = laborWithBDI + equipmentWithBDI + serviceWithBDI + otherWithBDI;
    
    // Aplicar incremento adicional se configurado
    if (itemConfig.additionalIncrement > 0) {
      const incrementMultiplier = 1 + itemConfig.additionalIncrement / 100;
      totalLaborItem = totalLaborItem * incrementMultiplier;
    }
    
    // Somar ao total geral
    totalMaterialWithBDI += materialWithBDI * qty;
    totalLaborWithBDI += totalLaborItem * qty;
    totalLaborHours += Number(item.totalLaborHours);
  }
  
  const totalCostWithBDI = totalMaterialWithBDI + totalLaborWithBDI;
  
  await db.update(budgets)
    .set({ totalCost: totalCostWithBDI.toFixed(2), totalLaborHours: totalLaborHours.toFixed(2) })
    .where(eq(budgets.id, budgetId));
}

// Schedule Activities
export async function getScheduleActivities(budgetId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(scheduleActivities).where(eq(scheduleActivities.budgetId, budgetId)).orderBy(scheduleActivities.order);
}

export async function getSchedulePeriods(activityId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(schedulePeriods).where(eq(schedulePeriods.activityId, activityId)).orderBy(schedulePeriods.periodStart);
}

// Disbursements
export async function getDisbursements(budgetId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(disbursements).where(eq(disbursements.budgetId, budgetId)).orderBy(disbursements.dueDate);
}

/**
 * Calcula valores com BDI aplicado
 * 
 * Regras:
 * - Encargos Sociais: aplicado APENAS em Mão de Obra
 * - Lucro + Impostos + Risco + Garantia: aplicado em TUDO (Material + M.O. + Equipamento)
 * 
 * Fórmula:
 * - M.O. com BDI = M.O. × (1 + encargos/100) × (1 + bdiGeral/100)
 * - Material com BDI = Material × (1 + bdiGeral/100)
 * - Equipamento com BDI = Equipamento × (1 + bdiGeral/100)
 */
export function applyBDI(params: {
  materialCost: number;
  laborCost: number;
  socialCharges: number; // %
  profit: number; // %
  taxes: number; // %
  risk: number; // %
  warranty: number; // %
}): {
  materialWithBDI: number;
  laborWithBDI: number;
  totalWithBDI: number;
  bdiGeneral: number; // % (lucro + impostos + risco + garantia)
} {
  const { materialCost, laborCost, socialCharges, profit, taxes, risk, warranty } = params;
  
  // BDI Geral (aplicado em tudo)
  const bdiGeneral = profit + taxes + risk + warranty;
  const bdiGeneralMultiplier = 1 + (bdiGeneral / 100);
  
  // Encargos Sociais (aplicado apenas em M.O.)
  const socialChargesMultiplier = 1 + (socialCharges / 100);
  
  // Cálculos
  const materialWithBDI = materialCost * bdiGeneralMultiplier;
  const laborWithBDI = laborCost * socialChargesMultiplier * bdiGeneralMultiplier;
  const totalWithBDI = materialWithBDI + laborWithBDI;
  
  return {
    materialWithBDI,
    laborWithBDI,
    totalWithBDI,
    bdiGeneral,
  };
}


// ============ CASH FLOW ENTRIES ============

export async function createCashFlowEntry(
  budgetId: number,
  month: string,
  type: 'entrada' | 'saida',
  category: string,
  description: string,
  amount: number,
  reference?: string
) {
  const db = await getDb();
  if (!db) return null;

  const result = await db.execute(sql.raw(
    `INSERT INTO cash_flow_entries (budgetId, month, type, category, description, amount, reference)
     VALUES (${budgetId}, '${month}', '${type}', '${category}', '${description}', ${amount}, ${reference ? `'${reference}'` : 'NULL'})`
  ));
  
  return result;
}

export async function getCashFlowEntries(budgetId: number, month?: string) {
  const db = await getDb();
  if (!db) return [];

  let query = `SELECT * FROM cash_flow_entries WHERE budgetId = ${budgetId}`;

  if (month) {
    query += ` AND month = '${month}'`;
  }

  query += ` ORDER BY month DESC, createdAt DESC`;

  const result = await db.execute(sql.raw(query));
  return (result as any[])[0] || [];
}

export async function getCashFlowSummary(budgetId: number, month: string) {
  const db = await getDb();
  if (!db) return { entradas: 0, saidas: 0, saldo: 0 };

  const result = await db.execute(sql.raw(
    `SELECT 
      SUM(CASE WHEN type = 'entrada' THEN amount ELSE 0 END) as entradas,
      SUM(CASE WHEN type = 'saida' THEN amount ELSE 0 END) as saidas
     FROM cash_flow_entries 
     WHERE budgetId = ${budgetId} AND month = '${month}'`
  ));

  const row = ((result as any[])[0] as any[])?.[0];
  if (!row) return { entradas: 0, saidas: 0, saldo: 0 };

  const entradas = Number(row.entradas) || 0;
  const saidas = Number(row.saidas) || 0;
  
  return {
    entradas,
    saidas,
    saldo: entradas - saidas
  };
}

export async function deleteCashFlowEntry(id: number) {
  const db = await getDb();
  if (!db) return false;

  await db.execute(sql.raw(
    `DELETE FROM cash_flow_entries WHERE id = ${id}`
  ));
  
  return true;
}

export async function clearCashFlowPeriod(budgetId: number, month: string) {
  const db = await getDb();
  if (!db) return 0;

  await db.execute(sql.raw(
    `DELETE FROM cash_flow_entries WHERE budgetId = ${budgetId} AND month = '${month}'`
  ));
  
  return 0;
}

export async function getTotalMeasurementByMonth(budgetId: number, month: string) {
  const db = await getDb();
  if (!db) return 0;

  const result = await db.execute(sql.raw(
    `SELECT SUM(valueMeasured) as total FROM measurement_items 
     WHERE budgetId = ${budgetId} AND DATE_FORMAT(createdAt, '%Y-%m') = '${month}'`
  ));

  const row = ((result as any[])[0] as any[])?.[0];
  return Number(row?.total) || 0;
}

export async function getGanttDisburseByMonth(budgetId: number, month: string) {
  const db = await getDb();
  if (!db) return 0;

  const result = await db.execute(sql.raw(
    `SELECT SUM(amount) as total FROM budget_monthly_distribution 
     WHERE budgetId = ${budgetId} AND month = '${month}'`
  ));

  const row = ((result as any[])[0] as any[])?.[0];
  return Number(row?.total) || 0;
}


// ===== TRANSAÇÕES FINANCEIRAS =====

export async function listFinancialTransactions(
  budgetId: number,
  filters?: {
    startDate?: string;
    endDate?: string;
    type?: 'entrada' | 'saida';
    category?: string;
  }
) {
  const db = await getDb();
  if (!db) return [];

  const conditions: any[] = [eq(financialTransactions.budgetId, budgetId)];

  if (filters?.startDate) {
    conditions.push(sql`${financialTransactions.date} >= ${filters.startDate}`);
  }
  if (filters?.endDate) {
    conditions.push(sql`${financialTransactions.date} <= ${filters.endDate}`);
  }
  if (filters?.type) {
    conditions.push(eq(financialTransactions.type, filters.type));
  }
  if (filters?.category) {
    conditions.push(eq(financialTransactions.category, filters.category));
  }

  return await db.select()
    .from(financialTransactions)
    .where(and(...conditions))
    .orderBy(desc(financialTransactions.date));
}

export async function getFinancialSummary(budgetId: number) {
  const db = await getDb();
  if (!db) return { totalEntradas: 0, totalSaidas: 0, saldoLiquido: 0 };

  const entradas = await db.select({ total: sql<number>`SUM(value)` })
    .from(financialTransactions)
    .where(and(
      eq(financialTransactions.budgetId, budgetId),
      eq(financialTransactions.type, 'entrada')
    ));

  const saidas = await db.select({ total: sql<number>`SUM(value)` })
    .from(financialTransactions)
    .where(and(
      eq(financialTransactions.budgetId, budgetId),
      eq(financialTransactions.type, 'saida')
    ));

  const totalEntradas = Number(entradas[0]?.total) || 0;
  const totalSaidas = Number(saidas[0]?.total) || 0;

  return {
    totalEntradas,
    totalSaidas,
    saldoLiquido: totalEntradas - totalSaidas,
  };
}

export async function createFinancialTransaction(data: {
  budgetId: number;
  date: string;
  type: 'entrada' | 'saida';
  category?: string;
  description: string;
  payeeName?: string;
  value: number;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  let finalDescription = data.description;
  if (data.payeeName) {
    finalDescription = `${data.description} (${data.payeeName})`;
  }

  // Use sql raw to insert date string directly, avoiding mysql2 timezone conversion
  // new Date(dateString) in UTC-4 server would shift '2026-05-02' to '2026-05-01'
  const result = await db.execute(
    sql`INSERT INTO financial_transactions (budgetId, date, type, category, description, value) VALUES (${data.budgetId}, ${data.date}, ${data.type}, ${data.category || null}, ${finalDescription}, ${data.value.toString()})`
  );

  return result;
}

export async function updateFinancialTransaction(
  id: number,
  data: Partial<{
    date: string;
    type: 'entrada' | 'saida';
    category: string;
    description: string;
    payeeName: string;
    value: number;
  }>
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  // Build update object for non-date fields (Drizzle ORM handles these correctly)
  const updateObj: any = {};
  if (data.type) updateObj.type = data.type;
  if (data.category !== undefined) updateObj.category = data.category;
  if (data.description !== undefined || data.payeeName !== undefined) {
    const desc = data.description || '';
    const payee = data.payeeName || '';
    updateObj.description = payee ? `${desc} (${payee})` : desc;
  }
  if (data.value !== undefined) updateObj.value = data.value;

  // Update non-date fields first
  if (Object.keys(updateObj).length > 0) {
    await db.update(financialTransactions).set(updateObj).where(eq(financialTransactions.id, id));
  }

  // Update date separately using raw SQL to avoid mysql2 timezone conversion
  // mysql2 driver converts Date objects to local timezone (America/New_York = UTC-4)
  // which would shift '2026-05-02' to '2026-05-01' in the database
  if (data.date) {
    const dateStr = data.date; // e.g. '2026-05-02' - pass as string literal
    return await db.execute(
      sql`UPDATE financial_transactions SET date = ${sql.raw(`'${dateStr}'`)} WHERE id = ${id}`
    );
  }
}

export async function deleteFinancialTransaction(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.delete(financialTransactions)
    .where(eq(financialTransactions.id, id));
}

// ============================================================
// MÓDULO FINANCEIRO CORPORATIVO
// ============================================================

// ---- Bank Accounts ----

export async function listBankAccounts(userId: number) {
  return rawQuery(`SELECT * FROM bank_accounts WHERE userId = ${userId} ORDER BY name`);
}

export async function createBankAccount(userId: number, data: {
  name: string; bank: string; type: 'corrente' | 'poupanca' | 'caixa';
  agency?: string; accountNumber?: string; initialBalance: number;
}) {
  const name = data.name.replace(/'/g, "''");
  const bank = data.bank.replace(/'/g, "''");
  const agency = data.agency ? `'${data.agency.replace(/'/g, "''")}'` : 'NULL';
  const accountNumber = data.accountNumber ? `'${data.accountNumber.replace(/'/g, "''")}'` : 'NULL';
  return rawQuery(`INSERT INTO bank_accounts (userId, name, bank, type, agency, accountNumber, initialBalance, isActive) VALUES (${userId}, '${name}', '${bank}', '${data.type}', ${agency}, ${accountNumber}, ${data.initialBalance}, 1)`);
}

export async function updateBankAccount(id: number, userId: number, data: Partial<{
  name: string; bank: string; type: 'corrente' | 'poupanca' | 'caixa';
  agency: string; accountNumber: string; initialBalance: number; isActive: boolean;
}>) {
  const parts: string[] = [];
  if (data.name !== undefined) parts.push(`name = '${data.name.replace(/'/g, "''")}'`);
  if (data.bank !== undefined) parts.push(`bank = '${data.bank.replace(/'/g, "''")}'`);
  if (data.type !== undefined) parts.push(`type = '${data.type}'`);
  if (data.agency !== undefined) parts.push(`agency = '${data.agency.replace(/'/g, "''")}'`);
  if (data.accountNumber !== undefined) parts.push(`accountNumber = '${data.accountNumber.replace(/'/g, "''")}'`);
  if (data.initialBalance !== undefined) parts.push(`initialBalance = ${data.initialBalance}`);
  if (data.isActive !== undefined) parts.push(`isActive = ${data.isActive ? 1 : 0}`);
  if (parts.length === 0) return;
  return rawQuery(`UPDATE bank_accounts SET ${parts.join(', ')} WHERE id = ${id} AND userId = ${userId}`);
}

export async function deleteBankAccount(id: number, userId: number) {
  return rawQuery(`DELETE FROM bank_accounts WHERE id = ${id} AND userId = ${userId}`);
}

export async function getBankAccountBalance(id: number, userId: number) {
  const accounts = await rawQuery(`SELECT * FROM bank_accounts WHERE id = ${id} AND userId = ${userId} LIMIT 1`);
  const account = accounts[0];
  if (!account) return null;
  const txRows = await rawQuery(`SELECT COALESCE(SUM(CASE WHEN type='entrada' THEN value ELSE 0 END), 0) as totalIn, COALESCE(SUM(CASE WHEN type='saida' THEN value ELSE 0 END), 0) as totalOut FROM financial_transactions WHERE bankAccountId = ${id} AND userId = ${userId}`);
  const row = txRows[0] || { totalIn: 0, totalOut: 0 };
  const balance = parseFloat(account.initialBalance) + parseFloat(row.totalIn) - parseFloat(row.totalOut);
  return { ...account, currentBalance: balance };
}

// ---- Fleet Vehicles ----

export async function listFleetVehicles(userId: number) {
  return rawQuery(`SELECT * FROM fleet_vehicles WHERE userId = ${userId} ORDER BY description`);
}

export async function createFleetVehicle(userId: number, data: {
  type: 'veiculo' | 'maquina'; description: string; plate?: string;
  model?: string; year?: number; notes?: string;
}) {
  const desc = data.description.replace(/'/g, "''");
  const plate = data.plate ? `'${data.plate.replace(/'/g, "''")}'` : 'NULL';
  const model = data.model ? `'${data.model.replace(/'/g, "''")}'` : 'NULL';
  const year = data.year ?? 'NULL';
  const notes = data.notes ? `'${data.notes.replace(/'/g, "''")}'` : 'NULL';
  return rawQuery(`INSERT INTO fleet_vehicles (userId, type, description, plate, model, year, status, notes) VALUES (${userId}, '${data.type}', '${desc}', ${plate}, ${model}, ${year}, 'ativo', ${notes})`);
}

export async function updateFleetVehicle(id: number, userId: number, data: Partial<{
  type: 'veiculo' | 'maquina'; description: string; plate: string;
  model: string; year: number; status: 'ativo' | 'inativo'; notes: string;
}>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const parts: string[] = [];
  if (data.type) parts.push(`type = '${data.type}'`);
  if (data.description !== undefined) parts.push(`description = '${data.description.replace(/'/g, "''")}'`);
  if (data.plate !== undefined) parts.push(`plate = ${data.plate ? `'${data.plate.replace(/'/g, "''")}'` : 'NULL'}`);
  if (data.model !== undefined) parts.push(`model = ${data.model ? `'${data.model.replace(/'/g, "''")}'` : 'NULL'}`);
  if (data.year !== undefined) parts.push(`year = ${data.year ?? 'NULL'}`);
  if (data.status) parts.push(`status = '${data.status}'`);
  if (data.notes !== undefined) parts.push(`notes = ${data.notes ? `'${data.notes.replace(/'/g, "''")}'` : 'NULL'}`);
  if (parts.length === 0) return;
  return rawQuery(`UPDATE fleet_vehicles SET ${parts.join(', ')} WHERE id = ${id} AND userId = ${userId}`);
}

export async function deleteFleetVehicle(id: number, userId: number) {
  return rawQuery(`DELETE FROM fleet_vehicles WHERE id = ${id} AND userId = ${userId}`);
}

// ---- Corporate Financial Transactions (Admin + Frota) ----

export async function createCorporateTransaction(userId: number, data: {
  costCenter: 'administrativo' | 'frota';
  date: string;
  type: 'entrada' | 'saida';
  category: string;
  description: string;
  value: number;
  bankAccountId?: number;
  vehicleId?: number;
  payeeName?: string;
}) {
  const bankAccId = data.bankAccountId ?? 'NULL';
  const vehId = data.vehicleId ?? 'NULL';
  const payee = data.payeeName ? `'${data.payeeName.replace(/'/g, "''")}'` : 'NULL';
  const desc = data.description.replace(/'/g, "''");
  const cat = data.category.replace(/'/g, "''");
  return rawQuery(
    `INSERT INTO financial_transactions (userId, costCenter, date, type, category, description, value, bankAccountId, vehicleId, payeeName)
     VALUES (${userId}, '${data.costCenter}', '${data.date}', '${data.type}', '${cat}', '${desc}', ${data.value}, ${bankAccId}, ${vehId}, ${payee})`
  );
}

export async function updateCorporateTransaction(id: number, userId: number, data: Partial<{
  date: string; type: 'entrada' | 'saida'; category: string;
  description: string; value: number; bankAccountId: number; vehicleId: number; payeeName: string;
}>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  // Build SET clause manually to avoid prepared statement issues with TiDBB
  const setClauses: string[] = [];
  if (data.date) setClauses.push(`date = '${data.date}'`);
  if (data.type) setClauses.push(`type = '${data.type}'`);
  if (data.category !== undefined) setClauses.push(`category = '${data.category.replace(/'/g, "''")}'`);
  if (data.description !== undefined) setClauses.push(`description = '${data.description.replace(/'/g, "''")}'`);
  if (data.value !== undefined) setClauses.push(`value = ${data.value}`);
  if (data.bankAccountId !== undefined) setClauses.push(`bankAccountId = ${data.bankAccountId}`);
  if (data.vehicleId !== undefined) setClauses.push(`vehicleId = ${data.vehicleId}`);
  if (data.payeeName !== undefined) setClauses.push(`payeeName = ${data.payeeName ? `'${data.payeeName.replace(/'/g, "''")}'` : 'NULL'}`);
  if (setClauses.length > 0) {
    await rawQuery(`UPDATE financial_transactions SET ${setClauses.join(', ')} WHERE id = ${id} AND userId = ${userId}`);
  }
}

export async function deleteCorporateTransaction(id: number, userId: number) {
  return rawQuery(`DELETE FROM financial_transactions WHERE id = ${id} AND userId = ${userId}`);
}

export async function listCorporateTransactions(userId: number, filters: {
  costCenter?: 'obra' | 'administrativo' | 'frota';
  dateFrom?: string; dateTo?: string;
  type?: 'entrada' | 'saida';
  bankAccountId?: number;
  vehicleId?: number;
  budgetId?: number;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  let whereClause = `userId = ${userId}`;
  if (filters.costCenter) whereClause += ` AND costCenter = '${filters.costCenter}'`;
  if (filters.dateFrom) whereClause += ` AND date >= '${filters.dateFrom}'`;
  if (filters.dateTo) whereClause += ` AND date <= '${filters.dateTo}'`;
  if (filters.type) whereClause += ` AND type = '${filters.type}'`;
  if (filters.bankAccountId) whereClause += ` AND bankAccountId = ${filters.bankAccountId}`;
  if (filters.vehicleId) whereClause += ` AND vehicleId = ${filters.vehicleId}`;
  if (filters.budgetId) whereClause += ` AND budgetId = ${filters.budgetId}`;

  return rawQuery(
    `SELECT ft.*, b.title as budgetTitle, ba.name as bankAccountName, fv.description as vehicleName
     FROM financial_transactions ft
     LEFT JOIN budgets b ON ft.budgetId = b.id
     LEFT JOIN bank_accounts ba ON ft.bankAccountId = ba.id
     LEFT JOIN fleet_vehicles fv ON ft.vehicleId = fv.id
     WHERE ft.${whereClause}
     ORDER BY ft.date DESC, ft.createdAt DESC`
  );
}

// ---- Corporate Finance Summary (Painel Geral) ----

export async function getCorporateSummary(userId: number, dateFrom: string, dateTo: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const kpiRows = await rawQuery(
    `SELECT costCenter, type, COALESCE(SUM(value), 0) as total
     FROM financial_transactions
     WHERE userId = ${userId} AND date >= '${dateFrom}' AND date <= '${dateTo}'
     GROUP BY costCenter, type`
  );

  const byBudget = await rawQuery(
    `SELECT b.id as budgetId, b.title as budgetTitle, b.workStatus,
      COALESCE(SUM(CASE WHEN ft.type='entrada' THEN ft.value ELSE 0 END), 0) as totalIn,
      COALESCE(SUM(CASE WHEN ft.type='saida' THEN ft.value ELSE 0 END), 0) as totalOut
     FROM budgets b
     LEFT JOIN financial_transactions ft ON ft.budgetId = b.id AND ft.userId = ${userId} AND ft.date >= '${dateFrom}' AND ft.date <= '${dateTo}'
     WHERE b.userId = ${userId} AND b.workStatus IN ('contrato', 'execucao')
     GROUP BY b.id, b.title, b.workStatus
     ORDER BY b.title`
  );

  const adminByCategory = await rawQuery(
    `SELECT category, type, COALESCE(SUM(value), 0) as total
     FROM financial_transactions
     WHERE userId = ${userId} AND costCenter = 'administrativo' AND date >= '${dateFrom}' AND date <= '${dateTo}'
     GROUP BY category, type`
  );

  const monthly = await rawQuery(
    `SELECT DATE_FORMAT(date, '%Y-%m') as month, type, COALESCE(SUM(value), 0) as total
     FROM financial_transactions
     WHERE userId = ${userId} AND date >= DATE_SUB('${dateTo}', INTERVAL 12 MONTH) AND date <= '${dateTo}'
     GROUP BY DATE_FORMAT(date, '%Y-%m'), type
     ORDER BY month ASC`
  );

  return { kpiRows, byBudget, adminByCategory, monthly };
}

// ---- Update Budget workStatus ----

export async function updateBudgetWorkStatus(id: number, userId: number, workStatus: 'orcamento' | 'contrato' | 'execucao' | 'finalizada' | 'nao_fechada') {
  await rawQuery(`UPDATE budgets SET workStatus = '${workStatus}' WHERE id = ${id} AND userId = ${userId}`);
  return { success: true };
}

// ---- Congelamento de Orçamento (Snapshot Completo) ----

/**
 * Copia todos os insumos de todas as composições do orçamento para budget_item_inputs.
 * Preserva customizações já existentes (não sobrescreve).
 * Após o snapshot, o orçamento é independente da base global.
 */
export async function snapshotBudgetInputs(budgetId: number): Promise<{ snapshotted: number; skipped: number }> {
  // Buscar todos os itens do orçamento que são composições (usando rawQuery para evitar prepared statements no TiDB)
  const items = await rawQuery(`SELECT id, compositionId FROM budget_items WHERE budgetId = ${budgetId} AND type = 'composition'`);

  let snapshotted = 0;
  let skipped = 0;

  for (const item of items) {
    if (!item.compositionId) continue;

    // Buscar insumos da composição base
    const compInputs = await getCompositionInputs(item.compositionId);
    if (!compInputs || compInputs.length === 0) continue;

    for (const ci of compInputs) {
      if (!ci.inputId || !ci.input) continue;

      // Verificar se já existe customização para este insumo neste item
      const existing = await rawQuery(`SELECT id FROM budget_item_inputs WHERE budgetItemId = ${item.id} AND inputId = ${ci.inputId} LIMIT 1`);

      if (existing.length > 0) {
        // Já customizado — preservar valor existente
        skipped++;
        continue;
      }

      // Inserir snapshot com valores atuais da base
      const coeff = String(ci.coefficient ?? '0').replace(/'/g, "''");
      const cost = String(ci.input?.unitCost ?? '0').replace(/'/g, "''");
      await rawQuery(`INSERT INTO budget_item_inputs (budgetItemId, inputId, coefficient, unitCost) VALUES (${item.id}, ${ci.inputId}, '${coeff}', '${cost}')`);
      snapshotted++;
    }
  }

  return { snapshotted, skipped };
}

/**
 * Congela o orçamento: faz snapshot de todos os insumos e marca frozenAt/frozenBy.
 */
export async function freezeBudget(budgetId: number, userId: number, frozenBy: string): Promise<{ success: boolean; snapshotted: number; skipped: number }> {
  // Verificar se o orçamento pertence ao usuário (usando rawQuery para evitar problema de prepared statements no TiDB)
  const rows = await rawQuery(`SELECT id FROM budgets WHERE id = ${budgetId} AND userId = ${userId} LIMIT 1`);
  if (!rows[0]) return { success: false, snapshotted: 0, skipped: 0 };

  // Fazer snapshot dos insumos
  const { snapshotted, skipped } = await snapshotBudgetInputs(budgetId);

  // Marcar como congelado
  await rawQuery(`UPDATE budgets SET frozenAt = NOW(), frozenBy = '${frozenBy.replace(/'/g, "''")}' WHERE id = ${budgetId} AND userId = ${userId}`);

  return { success: true, snapshotted, skipped };
}

/**
 * Descongela o orçamento: limpa frozenAt/frozenBy (mantém budget_item_inputs para preservar histórico).
 */
export async function unfreezeBudget(budgetId: number, userId: number): Promise<{ success: boolean }> {
  // Verificar se o orçamento pertence ao usuário (usando rawQuery para evitar problema de prepared statements no TiDB)
  const rows = await rawQuery(`SELECT id FROM budgets WHERE id = ${budgetId} AND userId = ${userId} LIMIT 1`);
  if (!rows[0]) return { success: false };

  await rawQuery(`UPDATE budgets SET frozenAt = NULL, frozenBy = NULL WHERE id = ${budgetId} AND userId = ${userId}`);

  return { success: true };
}
