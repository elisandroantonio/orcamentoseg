import mysql from 'mysql2/promise';

const DB_URL = "mysql://2ASSYqZeNL7nzRP.d5b8f8c4b82a:sS8lpl4KmQtej7lp69i0@gateway02.us-east-1.prod.aws.tidbcloud.com:4000/7rmYa7xiwR53zaRFAaits3?ssl={\"rejectUnauthorized\":true}";

async function main() {
  const conn = await mysql.createConnection(DB_URL);
  
  // Verificar composição PAR-104725
  const [rows] = await conn.execute(
    "SELECT id, code, description, unit FROM compositions WHERE code LIKE '%104725%' OR description LIKE '%alvenaria%blocos%' LIMIT 5"
  );
  console.log('Composições encontradas:', JSON.stringify(rows, null, 2));
  
  await conn.end();
}

main().catch(console.error);
