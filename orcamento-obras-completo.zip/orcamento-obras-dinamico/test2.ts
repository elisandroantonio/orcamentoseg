import * as db from './server/db';

async function test() {
  // Pegar item com stageId preenchido
  const items = await db.rawQuery('SELECT id, description, stageId, materialCost, totalCost, materialAdjustment FROM budget_items WHERE budgetId = 1080001 AND stageId IS NOT NULL LIMIT 3');
  console.log('Itens com stageId:');
  for (const i of items) console.log(`  id=${i.id} stageId=${i.stageId} mat=${i.materialCost} total=${i.totalCost} matAdj=${i.materialAdjustment}`);
  
  if (!items[0]) { console.log('Nenhum item com stageId'); return; }
  const item = items[0];
  
  // Pegar etapa deste item
  const stage = await db.rawQuery(`SELECT id, description, totalCost FROM budget_stages WHERE id = ${item.stageId}`);
  console.log(`\nEtapa ${stage[0]?.id}: totalCost ANTES = R$ ${stage[0]?.totalCost}`);
  
  // Salvar materialAdjustment=50
  await db.rawQuery(`UPDATE budget_items SET materialAdjustment = 50 WHERE id = ${item.id}`);
  console.log(`materialAdjustment=50 salvo para item ${item.id}`);
  
  // Recalcular
  await db.recalculateBudgetTotals(1080001);
  
  // Verificar etapa após
  const stageAfter = await db.rawQuery(`SELECT id, description, totalCost FROM budget_stages WHERE id = ${item.stageId}`);
  console.log(`Etapa ${stageAfter[0]?.id}: totalCost APÓS = R$ ${stageAfter[0]?.totalCost}`);
  
  const diff = Number(stageAfter[0]?.totalCost) - Number(stage[0]?.totalCost);
  console.log(`Diferença: R$ ${diff.toFixed(2)} (esperado: ~R$ ${(Number(item.materialCost) * 0.5).toFixed(2)})`);
  
  if (Math.abs(diff) > 1) {
    console.log('✅ RECÁLCULO FUNCIONOU!');
  } else {
    console.log('❌ RECÁLCULO NÃO FUNCIONOU - totalCost não mudou');
  }
  
  // Limpar
  await db.rawQuery(`UPDATE budget_items SET materialAdjustment = 0 WHERE id = ${item.id}`);
  await db.recalculateBudgetTotals(1080001);
}

test().catch(console.error).finally(() => process.exit(0));
