import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import Compositions from "./pages/Compositions";
import CompositionForm from "./pages/CompositionForm";
import Inputs from "./pages/Inputs";
import Categories from "./pages/Categories";
import Clients from "./pages/Clients";
import Projects from "./pages/Projects";
import ProjectForm from "./pages/ProjectForm";
import Budgets from "./pages/Budgets";
import BudgetForm from "./pages/BudgetForm";
import BudgetView from "./pages/BudgetView";
import BudgetDashboard from "./pages/BudgetDashboard";
import BudgetCharts from "./pages/BudgetCharts";
import BudgetGantt from "./pages/BudgetGantt";
import Financeiro from "./pages/Financeiro";
import BDICalculatorPage from "./pages/BDICalculatorPage";
import MaterialLists from "./pages/MaterialLists";
import MaterialListView from "./pages/MaterialListView";

function Router() {
  return (
    <Switch>
      <Route path={"/"} component={Home} />
      <Route path={"/compositions"} component={Compositions} />
      <Route path={"/compositions/new"} component={CompositionForm} />
      <Route path={"/compositions/:id"} component={CompositionForm} />
      <Route path={"/inputs"} component={Inputs} />
      <Route path={"/categories"} component={Categories} />
      <Route path={"/clients"} component={Clients} />
      <Route path={"/projects"} component={Projects} />
      <Route path={"/projects/new"} component={ProjectForm} />
      <Route path={"/projects/:id"} component={ProjectForm} />
      <Route path={"/budgets"} component={Budgets} />
      <Route path={"/budgets/new"} component={BudgetForm} />
      <Route path={"/budgets/:id"} component={BudgetDashboard} />
      <Route path={"/budgets/:id/view"} component={BudgetView} />
      <Route path={"/budgets/:id/edit"} component={BudgetForm} />
      <Route path={"/budgets/:id/charts"} component={BudgetCharts} />
      <Route path={"/budgets/:id/gantt"} component={BudgetGantt} />
      <Route path={"/financeiro"} component={Financeiro} />
      <Route path={"/bdi-calculator"} component={BDICalculatorPage} />
      <Route path={"/material-lists"} component={MaterialLists} />
      <Route path={"/material-lists/:id"} component={MaterialListView} />
      <Route path={"/404"} component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
