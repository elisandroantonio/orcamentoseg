import * as db from './server/db';

async function test() {
  const stage = await db.rawQuery('SELECT id, totalCost FROM budget_stages WHERE id = 5250001');
  console.log('Etapa 5250001 no banco AGORA:', JSON.stringify(stage[0]));
  
  const budget = await db.rawQuery('SELECT totalCost FROM budgets WHERE id = 1080001');
  console.log('Budget 1080001 totalCost:', JSON.stringify(budget[0]));
}

test().catch(console.error).finally(() => process.exit(0));
