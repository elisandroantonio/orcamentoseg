import * as db from './server/db';

async function test() {
  const items = await db.rawQuery('SELECT id, stageId, materialAdjustment FROM budget_items WHERE budgetId = 1080001 AND stageId IS NOT NULL LIMIT 3');
  console.log('Tipos dos campos:');
  for (const i of items) {
    console.log(`  id=${i.id}(${typeof i.id}) stageId=${i.stageId}(${typeof i.stageId}) matAdj=${i.materialAdjustment}(${typeof i.materialAdjustment})`);
  }
  
  const stages = await db.rawQuery('SELECT id FROM budget_stages WHERE budgetId = 1080001 LIMIT 3');
  console.log('\nTipos dos stages:');
  for (const s of stages) {
    console.log(`  id=${s.id}(${typeof s.id})`);
  }
  
  // Testar comparação
  const item = items[0];
  const stage = stages.find((s: any) => s.id === item.stageId);
  console.log(`\nComparação direta (===): ${stage ? '✅ ENCONTROU' : '❌ NÃO ENCONTROU'}`);
  const stageNum = stages.find((s: any) => Number(s.id) === Number(item.stageId));
  console.log(`Comparação com Number(): ${stageNum ? '✅ ENCONTROU' : '❌ NÃO ENCONTROU'}`);
}

test().catch(console.error).finally(() => process.exit(0));
